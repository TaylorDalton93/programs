
public interface Reducible {
	
	public boolean reduce();
	

}
