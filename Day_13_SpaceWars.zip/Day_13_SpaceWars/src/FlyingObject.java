
public interface FlyingObject {
	public boolean move();

}
