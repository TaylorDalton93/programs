import java.util.ArrayList;
import java.util.Scanner;

import cards.Card;
import cards.Deck;


public class BlackjackHand {
	private static ArrayList<Card> cards;
	private static final int MAX = 5;
	private static final int BLACKJACK = 21;
	
	/**
	 * Constructs an empty arraylist of cards
	 */
	BlackjackHand(){
		this.cards = new ArrayList<Card>();
	}
	
	/**
	 * Adds a card to the players hand
	 * @param c The added card
	 */
	public void addCard(Card c){
		if(cards.size() < MAX)
			cards.add(c);
		else
			throw new IllegalArgumentException("Your hand is full");
	}
	
	/**
	 * Returns the string representation of the blackjack hand
	 */
	@Override
	public String toString() {
		return "BlackjackHand [cards=" + cards + "]";
	}

	/**
	 * Gets the size of your hand
	 * @return Returns the size
	 */
	public int size(){
		return cards.size();
	}
	
	/**
	 * Checks to see if the hand is empty
	 * @return Returns true if the hand is empty and false otherwise
	 */
	public boolean isEmpty(){
		if(cards.size() == 0)
			return true;
		return false;
	}
	
	/**
	 * Checks to see if the player has blackjack
	 * @return Returns true if the player has achieved blackjack and false otherwise
	 */
	public static boolean blackjack(){
		if(total() == BLACKJACK)
			return true;
		return false;
			
	}
	
	/**
	 * Checks to see if the total of the hand has exceeded 21
	 * @return Returns true if the hand exceeds 21 and false otherwise
	 */
	public static boolean busted(){
		return total() > BLACKJACK;
	}
	
	/**
	 * @return Returns the soft total of the hand
	 */
	public static int softTotal(){
		for(int i = 0; i < cards.size(); i++){
			if((cards.get(i).getValue() == 10) || (cards.get(i).getValue() == 11) ||
					(cards.get(i).getValue() == 12) || (cards.get(i).getValue() == 13)){
				return total() + 10;
			}
				
		}
		return total();
	}
	
	/** 
	 * @return Returns the hardTotal of the hand
	 */
	public static int hardTotal(){
		return total();
		
	}
	
	/**
	 * @return Returns the total of the cards in the hand
	 */
	public static int total(){
		int value = 0;
		
		for(Card c : cards)
			value += c.getValue();
		return value;
	}
	
	

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Deck deck = new Deck();
		BlackjackHand hand = new BlackjackHand();
		String choice = "";
		
		hand.addCard(deck.deal());
		hand.addCard(deck.deal());
		
		do{
			System.out.println("Welcome to blackjack...Here are your cards: "+cards.toString());
			hand.addCard(deck.deal());
			System.out.println(hand.total() + " , (h)it or (s)tand?");
			choice = in.nextLine();
		}while(choice.equals("h") && busted() == false && blackjack() == false);
		
		if(busted() == true)
			System.out.println("Busted!! You lose 100");
		
		if(blackjack() == true)
			System.out.println("BLACKJACK!!!! You win 200");
		
	    if(choice.equals("s") && busted() == false)
			System.out.println("You ended with "+total());

	}

}
