package cards;
public class Card {
	private int value;
	private int suit;
	
	public final static int CLUBS = 1;
	public final static int HEARTS = 2;
	public final static int SPADES = 3;
	public final static int DIAMONDS = 4;
	
	public final static int ACE = 1;
	public final static int JACK = 11;
	public final static int QUEEN = 12;
	public final static int KING = 13;
	
	/**
	 * Constructs a card using the specified value and suit
	 * @param value The value of the card
	 * @param suit The suit
	 */
	public Card(int value, int suit){
		if(value > 13 )
			throw new IllegalArgumentException("Illegal card value: "+value);
		else if(suit > 4)
			throw new IllegalArgumentException("Illegal card suit: "+suit);
		else
			this.value = value;
			this.suit = suit;
	}
	/**
	 * Returns the value of the given card
	 * @return The value of the card
	 */
	public int getValue(){
		return value;
	}
	
	/**
	 * Returns the suit of the card in a numerical format
	 * @return The suit
	 */
	public int getSuit(){
		return suit;
	}
	
	/**
	 * Returns the String representation of the card
	 */
	public String toString(){
		String value = "";
		String suit = "";
		if(this.value == ACE)
			value = "A";
		if(this.value == JACK)
			value = "J";
		if(this.value == QUEEN)
			value = "Q";
		if(this.value == KING)
			value = "K";
		if(this.suit == CLUBS)
			suit = "C";
		if(this.suit == HEARTS)
			suit = "H";
		if(this.suit == SPADES)
			suit = "S";
		if(this.suit == DIAMONDS)
			suit = "D";
		
		return value + suit;
	}
	
	/**
	 * Determines whether or not two cards are the same
	 * Returns true if they are the same and false if not
	 */
	@Override
	public boolean equals(Object that){
		if(that instanceof Card){
			if(this.value == ((Card)that).value && this.suit == ((Card)that).suit)
				return true;
			else
				return false;
		}
		return false;
	}

	public static void main(String[] args) {
		Card c1 = new Card(11, 2);
		Card c2 = new Card(1, 3);
		System.out.println(c2.toString());
		System.out.println(c1.toString());
		System.out.println(c1.equals(c2));
		System.out.println(c1.getValue());
		System.out.println(c1.getSuit());
		

	}

}
