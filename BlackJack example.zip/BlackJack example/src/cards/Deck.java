package cards;

import java.util.ArrayList;
import java.util.Collections;
import cards.Card;


public class Deck {
	
	private ArrayList<Card> cards;
	public int usedCards;
	
	public Deck(){
		cards = new ArrayList<Card>(52);
		for(int i = 0; i < 13; i++)
			for(int j = 0; j < 4; j++){
				Card newCard = new Card(i,j);
				cards.add(newCard);
			}
	}
	
	/**
	 * Deals a card
	 * @return The card that has been dealt
	 */
	public Card deal(){
		Card c = cards.get((int)(Math.random() * cards.size()));
		cards.remove(c);
		return c;
	}
	
	/**
	 * Gets the size of the deck
	 * @return Returns the number of cards remaining in the deck
	 */
	public int size(){
		int s = 0;
		if(!isEmpty()){
			for(Card c : cards)
				s++;
		}
		return s;
	}
	
	/**
	 * Returns a string representation of the deck
	 */
	public String toString(){
		String card = "";
		
		for(Card c : cards)
			card += c + " ";
		return card;
	}
	
	/**
	 * Checks to see if the deck is empty
	 * @return Returns true if the deck is empty and false if it is not
	 */
	public boolean isEmpty(){
		if(cards.size() == 0){
			System.out.println("This deck is empty");
			return true;
		}
		return false;
	}
	
	/**
	 * Shuffles the deck
	 */
	public void shuffle(){
		Collections.shuffle(cards);
	}
	
	/**
	 * Refills the deck with cards in the same order. Does not reshuffle.
	 */
	public void reset(){
		this.cards = new ArrayList<Card>(52);
		
	}

	public static void main(String[] args) {
		Deck d = new Deck();
		System.out.println(d.toString());
		System.out.println(d.isEmpty());
		d.shuffle();
		System.out.println(d.toString());
		d.reset();
		System.out.println(d.toString());
		System.out.println(d.size());

	}

}
